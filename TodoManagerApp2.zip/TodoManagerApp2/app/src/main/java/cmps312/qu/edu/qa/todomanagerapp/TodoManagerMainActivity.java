package cmps312.qu.edu.qa.todomanagerapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

public class TodoManagerMainActivity extends AppCompatActivity {
ListView listView ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo_manager_main);
        listView = (ListView) findViewById(R.id.items_list_view);
        View footerView = View.inflate(this, R.layout.list_footer, null);
        listView.addFooterView(footerView);

    }
}
